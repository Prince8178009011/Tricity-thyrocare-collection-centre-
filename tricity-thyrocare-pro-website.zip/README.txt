TRICITY THYROCARE PRO WEBSITE
==============================

Files:
- index.html
- style.css
- script.js
- images/ (package creatives)

How to publish on GitHub Pages:
1. Open your existing GitHub repository.
2. Replace the old index.html, style.css and script.js.
3. Upload the complete images folder.
4. Commit changes.
5. Wait 1-3 minutes and refresh the GitHub Pages website.

Contact details already included:
Phone: 8178009011
Email: tricitythyrocarecollectioncent@gmail.com

The package creatives are used as package-card images and open in a large popup when "View package" is tapped.

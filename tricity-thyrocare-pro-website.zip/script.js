const menu=document.querySelector('.menu');
const nav=document.querySelector('.nav nav');
if(menu) menu.addEventListener('click',()=>nav.classList.toggle('open'));

document.querySelectorAll('.nav nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));

const modal=document.getElementById('modal');
const modalImg=document.getElementById('modalImg');
document.querySelectorAll('.view').forEach(btn=>{
  btn.addEventListener('click',()=>{
    modalImg.src=btn.dataset.img;
    modal.classList.add('show');
    document.body.style.overflow='hidden';
  });
});
function closeModal(){modal.classList.remove('show');document.body.style.overflow='';}
document.getElementById('close').addEventListener('click',closeModal);
document.querySelector('.modal-bg').addEventListener('click',closeModal);
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});

const reveal=document.querySelectorAll('.pkg,.service,.why-panel');
const io=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';io.unobserve(e.target)}});
},{threshold:.08});
reveal.forEach(el=>{el.style.opacity='0';el.style.transform='translateY(18px)';el.style.transition='opacity .6s ease, transform .6s ease';io.observe(el);});
